<?php

require_once 'libs/smarty_4_3_1/config.php';
class  control{
    
    private $model;
    private $view;
    
    function __construct() {
        $this->model = null;
        $this->view  = new config();
    }
    
    public function getModel() {
        return $this->model;
    }

    public function getView() {
        return $this->view;
    }

    public function setModel($model): void {
        $this->model = $model;
    }

    public function setView($view): void {
        $this->view = $view;
    }
    public function gestion_procesos() {
        
        if(isset($_REQUEST['accion'])){
           $accion = $_REQUEST['accion'];
           
           switch ($accion) {
               case 'calcular':
                    $this->fn_calculos();

                   break;

               default:
                  $this->view->Display("calculadora.tpl");
           }
           
               
            
        }else{
            $this->view->Display("calculadora.tpl");
        }
 
        
    }
    public function fn_calculos() {
        
        $v1 = $_REQUEST['v1'];
        $oper = $_REQUEST['cbo_operacion'];
        $v2 = $_REQUEST['v2'];
        $rs = 0;
        if( $oper=="+"){
           $rs = $v1+$v2;   
           echo "El resultado de sumar($v1 y  $v2 )=".$rs;
        }
        if( $oper=="-"){
           $rs = $v1-$v2;   
           echo "El resultado de restar($v1 y $v2 )=".$rs;
        }     
    }

    public function saludar() {
        $valor = "Progra 3";
        $this->view->Assign("TITULO", $valor);
        $this->view->Assign("nombre", 'Royner');
        
        $arrMeses = array("Enero","Febrero","Marzo","Abril","Mayo","Junio");
        /*
        $arrMeses[0] = "Enero";
        $arrMeses[1] = "Febrero";
        $arrMeses[2] = "Marzo";
        $arrMeses[3] = "Abril";
        $arrMeses[4] = "Mayo";
        $arrMeses[5] = "Junio";*/
        $this->view->Assign("arrMeses", $arrMeses);
        
        $this->view->Display("prueba.tpl");
        
         
    }

    
}

?>
